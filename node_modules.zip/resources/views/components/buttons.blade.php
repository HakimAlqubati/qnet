<div class="ml-10 space-x-4">
    <button href="/login" class="bg-gray-500">Log in</<button>
    <button href="/register" class="bg-blue-500">Register</<button>
    <button href="/contact" class="bg-green-500">Contact</<button>
    <button href="/about" class="bg-yellow-500">About</<button>
</div>
<button href="/login" class="bg-gray-500">Log in</<button>
<button href="/register" class="bg-blue-500">Register</<button>
<button href="/contact" class="bg-green-500">Contact</<button>
<button href="/about" class="bg-yellow-500">About</<button>
