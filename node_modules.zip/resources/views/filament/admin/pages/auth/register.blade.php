<x-filament::page>
    <div class="flex flex-col items-center justify-center min-h-screen bg-gray-100">
        <div class="w-full max-w-4xl bg-white shadow-lg rounded-lg p-10">
            {{ $this->form }}
        </div>
    </div>
</x-filament::page>
