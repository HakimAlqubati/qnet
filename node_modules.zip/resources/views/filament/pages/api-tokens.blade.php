<x-filament::page>
    <x-filament::card>
        @livewire(\Laravel\Jetstream\Http\Livewire\ApiTokenManager::class)
    </x-filament::card>
</x-filament::page>
