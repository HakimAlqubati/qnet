<x-filament-panels::page.simple>
    <div class="mt-5">
        @livewire(\Laravel\Jetstream\Http\Livewire\CreateTeamForm::class)
    </div>
   
</x-filament-panels::page.simple>
