<x-filament-panels::page>
    {{-- <livewire:pedigree-chart />
    <livewire:fan-chart-component />
    <livewire:descendant-chart-component />
    <livewire:daboville-report /> --}}
</x-filament-panels::page>
