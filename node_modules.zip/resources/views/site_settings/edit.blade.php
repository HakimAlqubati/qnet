@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Site Setting</h1>
</div>
@endsection
