-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2025 at 08:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oday_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bv_history`
--

CREATE TABLE `bv_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `direction` enum('right','left') NOT NULL,
  `bv_value` decimal(10,2) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bv_history`
--

INSERT INTO `bv_history` (`id`, `user_id`, `direction`, `bv_value`, `description`, `created_at`, `updated_at`) VALUES
(1, 2, 'right', 5.00, 'w', '2025-02-07 22:37:25', '2025-02-07 22:37:25'),
(2, 2, 'left', 4.00, 'qe\n', '2025-02-07 22:37:41', '2025-02-07 22:37:41'),
(3, 3, 'left', 3.00, '', '2025-02-07 23:04:48', '2025-02-07 23:04:48');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `session_id` varchar(191) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `country_id`, `created_at`, `updated_at`) VALUES
(1, 'Sanaa', 1, '2025-02-07 23:46:54', '2025-02-07 23:46:54'),
(2, 'Taiz', 1, '2025-02-07 23:47:00', '2025-02-07 23:47:05');

-- --------------------------------------------------------

--
-- Table structure for table `collections`
--

CREATE TABLE `collections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `collections`
--

INSERT INTO `collections` (`id`, `name`, `description`, `price`, `created_at`, `updated_at`, `team_id`) VALUES
(1, 'Summer Sale', 'Discounted products for the summer season.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(2, 'Best Sellers', 'Our most popular products.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(3, 'New Arrivals', 'Latest products added to our store.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(4, 'Gift Ideas', 'Perfect gifts for any occasion.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `collection_items`
--

CREATE TABLE `collection_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `collection_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `connected_accounts`
--

CREATE TABLE `connected_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(191) NOT NULL,
  `provider_id` varchar(191) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `nickname` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `telephone` varchar(191) DEFAULT NULL,
  `avatar_path` text DEFAULT NULL,
  `token` varchar(1000) NOT NULL,
  `secret` varchar(191) DEFAULT NULL,
  `refresh_token` varchar(1000) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Yemen', 'YE', '2025-02-07 23:46:36', '2025-02-07 23:46:36');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(191) NOT NULL,
  `type` enum('percentage','fixed') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NULL DEFAULT NULL,
  `max_uses` int(11) DEFAULT NULL,
  `min_purchase_amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(191) NOT NULL,
  `last_name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone_number` int(11) NOT NULL,
  `address` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL,
  `postal_code` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `downloadable_products`
--

CREATE TABLE `downloadable_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `file_url` varchar(191) NOT NULL,
  `download_limit` int(11) NOT NULL,
  `expiration_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `path` varchar(191) NOT NULL,
  `url` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_logs`
--

CREATE TABLE `inventory_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity_change` int(11) NOT NULL,
  `reason` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `invoice_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `mime_type` varchar(191) DEFAULT NULL,
  `disk` varchar(191) NOT NULL,
  `conversions_disk` varchar(191) DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Product', 30, '112d44ca-53cf-4236-9b39-8b2a55991731', 'default', 'qnet_ornage_white', 'product-qnet_ornage_white.png', 'image/png', 'public', 'public', 431, '[]', '[]', '[]', '[]', 1, '2025-02-07 21:26:00', '2025-02-07 21:26:00'),
(2, 'App\\Models\\Product', 30, '2b650f55-8cde-4d78-ac78-2083d51dee63', 'default', 'qnet_logo_white_black', 'product-qnet_logo_white_black.png', 'image/png', 'public', 'public', 1217, '[]', '[]', '[]', '[]', 2, '2025-02-07 21:26:00', '2025-02-07 21:26:00'),
(3, 'App\\Models\\Product', 30, '1aaa0c69-8ca8-49de-b041-422dc1315bb2', 'default', 'qnet_logo', 'product-qnet_logo.png', 'image/png', 'public', 'public', 5074, '[]', '[]', '[]', '[]', 3, '2025-02-07 21:26:00', '2025-02-07 21:26:00');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `url` varchar(191) NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `url`, `parent_id`, `order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(7, 'Shop', '/categories', NULL, 3, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_make_password_nullable_on_users_table', 1),
(3, '0001_01_01_000002_create_connected_accounts_table', 1),
(4, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(5, '2019_08_19_000000_create_failed_jobs_table', 1),
(6, '2020_05_21_100000_create_teams_table', 1),
(7, '2020_05_21_200000_create_team_user_table', 1),
(8, '2020_05_21_300000_create_team_invitations_table', 1),
(9, '2022_09_26_113707_create_product_categories_table', 1),
(10, '2022_09_26_113708_create_products_table', 1),
(11, '2023_04_01_000000_create_downloadable_products_table', 1),
(12, '2023_04_01_000000_create_payment_methods_table', 1),
(13, '2023_04_01_000000_create_site_settings_table', 1),
(14, '2023_04_01_000001_create_ratings_table', 1),
(15, '2023_04_03_000000_create_reviews_table', 1),
(16, '2023_06_01_000000_create_wishlists_table', 1),
(17, '2023_09_26_010935_create_variations_table', 1),
(18, '2023_09_26_113743_create_customers_table', 1),
(19, '2023_09_26_113752_create_orders_table', 1),
(20, '2023_09_27_130936_create_cart_items_table', 1),
(21, '2023_09_28_010654_create_tags_table', 1),
(22, '2023_09_28_010821_create_images_table', 1),
(23, '2023_09_28_010933_create_product_images_table', 1),
(24, '2023_09_28_011302_create_product_tag_table', 1),
(25, '2023_09_28_013747_create_product_variation_table', 1),
(26, '2023_09_28_014231_create_group_table', 1),
(27, '2023_09_28_014549_create_product_group_table', 1),
(28, '2023_09_28_015116_create_simple_product_table', 1),
(29, '2023_09_28_021219_create_product_rating_table', 1),
(30, '2023_09_28_021229_create_product_reviews_table', 1),
(31, '2023_09_28_132432_create_order_items_table', 1),
(32, '2023_09_30_151612_create_invoices_table', 1),
(33, '2023_10_01_000000_create_inventory_logs_table', 1),
(34, '2024_01_01_000010_create_coupons_table', 1),
(35, '2024_02_21_190705_create_permission_tables', 1),
(36, '2024_07_24_080000_create_menus_table', 1),
(37, '2024_09_09_152656_create_collections_table', 1),
(38, '2024_09_09_153154_create_collection_items_table', 1),
(39, '2024_09_25_110504_create_articles_table', 1),
(40, '2024_09_25_223311_create_pages_table', 1),
(41, '2024_09_29_093707_add_team_to_resources', 1),
(42, '2025_02_04_031745_create_bv_history_table', 2),
(43, '2025_02_04_032457_create_rsp_history_table', 2),
(44, '2025_02_08_001230_create_media_table', 2),
(45, '2025_02_08_001712_add_inventory_count_to_products_table', 3),
(46, '2025_02_08_001801_add_inventory_count_and_low_stock_threshold_to_products_table', 4),
(47, '2025_02_08_002212_add_description_products_table', 5),
(48, '2025_02_08_002545_update_featured_image_nullable_in_products', 6),
(49, '2025_02_08_010259_add_phonenumber_to_users_table', 7),
(50, '2025_02_08_012408_add_bv_to_products_table', 8),
(51, '2025_02_08_014720_add_user_type_and_parent_id_to_users_table', 9),
(52, '2025_02_08_022553_create_ranks_table', 10),
(53, '2025_02_08_023618_create_countries_table', 11),
(54, '2025_02_08_025000_add_country_city_rank_to_users_table', 12),
(55, '2025_02_10_010449_add_image_to_product_categories_table', 13),
(56, '2025_02_10_013443_create_user_plans_table', 13),
(57, '2025_02_10_014426_add_created_by_to__user_plans_table', 13),
(58, '2025_02_10_021358_add_active_and_address_to_users_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `order_date` varchar(191) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `payment_status` varchar(191) NOT NULL,
  `shipping_status` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `orderable_type` varchar(191) NOT NULL,
  `orderable_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price, 10, 2` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `content` text DEFAULT NULL,
  `parent_page_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `details` text NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'view_cart::item', 'web', '2024-09-04 11:12:04', '2024-09-04 11:12:04'),
(2, 'view_any_cart::item', 'web', '2024-09-04 11:12:05', '2024-09-04 11:12:05'),
(3, 'create_cart::item', 'web', '2024-09-04 11:12:05', '2024-09-04 11:12:05'),
(4, 'update_cart::item', 'web', '2024-09-04 11:12:05', '2024-09-04 11:12:05'),
(5, 'restore_cart::item', 'web', '2024-09-04 11:12:05', '2024-09-04 11:12:05'),
(6, 'restore_any_cart::item', 'web', '2024-09-04 11:12:05', '2024-09-04 11:12:05'),
(7, 'replicate_cart::item', 'web', '2024-09-04 11:12:05', '2024-09-04 11:12:05'),
(8, 'reorder_cart::item', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(9, 'delete_cart::item', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(10, 'delete_any_cart::item', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(11, 'force_delete_cart::item', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(12, 'force_delete_any_cart::item', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(13, 'view_customer', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(14, 'view_any_customer', 'web', '2024-09-04 11:12:06', '2024-09-04 11:12:06'),
(15, 'create_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(16, 'update_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(17, 'restore_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(18, 'restore_any_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(19, 'replicate_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(20, 'reorder_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(21, 'delete_customer', 'web', '2024-09-04 11:12:07', '2024-09-04 11:12:07'),
(22, 'delete_any_customer', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(23, 'force_delete_customer', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(24, 'force_delete_any_customer', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(25, 'view_group', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(26, 'view_any_group', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(27, 'create_group', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(28, 'update_group', 'web', '2024-09-04 11:12:08', '2024-09-04 11:12:08'),
(29, 'restore_group', 'web', '2024-09-04 11:12:09', '2024-09-04 11:12:09'),
(30, 'restore_any_group', 'web', '2024-09-04 11:12:09', '2024-09-04 11:12:09'),
(31, 'replicate_group', 'web', '2024-09-04 11:12:09', '2024-09-04 11:12:09'),
(32, 'reorder_group', 'web', '2024-09-04 11:12:09', '2024-09-04 11:12:09'),
(33, 'delete_group', 'web', '2024-09-04 11:12:10', '2024-09-04 11:12:10'),
(34, 'delete_any_group', 'web', '2024-09-04 11:12:10', '2024-09-04 11:12:10'),
(35, 'force_delete_group', 'web', '2024-09-04 11:12:10', '2024-09-04 11:12:10'),
(36, 'force_delete_any_group', 'web', '2024-09-04 11:12:10', '2024-09-04 11:12:10'),
(37, 'view_invoice', 'web', '2024-09-04 11:12:10', '2024-09-04 11:12:10'),
(38, 'view_any_invoice', 'web', '2024-09-04 11:12:10', '2024-09-04 11:12:10'),
(39, 'create_invoice', 'web', '2024-09-04 11:12:11', '2024-09-04 11:12:11'),
(40, 'update_invoice', 'web', '2024-09-04 11:12:11', '2024-09-04 11:12:11'),
(41, 'restore_invoice', 'web', '2024-09-04 11:12:11', '2024-09-04 11:12:11'),
(42, 'restore_any_invoice', 'web', '2024-09-04 11:12:11', '2024-09-04 11:12:11'),
(43, 'replicate_invoice', 'web', '2024-09-04 11:12:11', '2024-09-04 11:12:11'),
(44, 'reorder_invoice', 'web', '2024-09-04 11:12:11', '2024-09-04 11:12:11'),
(45, 'delete_invoice', 'web', '2024-09-04 11:12:12', '2024-09-04 11:12:12'),
(46, 'delete_any_invoice', 'web', '2024-09-04 11:12:12', '2024-09-04 11:12:12'),
(47, 'force_delete_invoice', 'web', '2024-09-04 11:12:12', '2024-09-04 11:12:12'),
(48, 'force_delete_any_invoice', 'web', '2024-09-04 11:12:12', '2024-09-04 11:12:12'),
(49, 'view_order', 'web', '2024-09-04 11:12:12', '2024-09-04 11:12:12'),
(50, 'view_any_order', 'web', '2024-09-04 11:12:12', '2024-09-04 11:12:12'),
(51, 'create_order', 'web', '2024-09-04 11:12:13', '2024-09-04 11:12:13'),
(52, 'update_order', 'web', '2024-09-04 11:12:13', '2024-09-04 11:12:13'),
(53, 'restore_order', 'web', '2024-09-04 11:12:13', '2024-09-04 11:12:13'),
(54, 'restore_any_order', 'web', '2024-09-04 11:12:13', '2024-09-04 11:12:13'),
(55, 'replicate_order', 'web', '2024-09-04 11:12:13', '2024-09-04 11:12:13'),
(56, 'reorder_order', 'web', '2024-09-04 11:12:14', '2024-09-04 11:12:14'),
(57, 'delete_order', 'web', '2024-09-04 11:12:14', '2024-09-04 11:12:14'),
(58, 'delete_any_order', 'web', '2024-09-04 11:12:14', '2024-09-04 11:12:14'),
(59, 'force_delete_order', 'web', '2024-09-04 11:12:14', '2024-09-04 11:12:14'),
(60, 'force_delete_any_order', 'web', '2024-09-04 11:12:14', '2024-09-04 11:12:14'),
(61, 'view_order::item', 'web', '2024-09-04 11:12:14', '2024-09-04 11:12:14'),
(62, 'view_any_order::item', 'web', '2024-09-04 11:12:15', '2024-09-04 11:12:15'),
(63, 'create_order::item', 'web', '2024-09-04 11:12:15', '2024-09-04 11:12:15'),
(64, 'update_order::item', 'web', '2024-09-04 11:12:15', '2024-09-04 11:12:15'),
(65, 'restore_order::item', 'web', '2024-09-04 11:12:15', '2024-09-04 11:12:15'),
(66, 'restore_any_order::item', 'web', '2024-09-04 11:12:15', '2024-09-04 11:12:15'),
(67, 'replicate_order::item', 'web', '2024-09-04 11:12:16', '2024-09-04 11:12:16'),
(68, 'reorder_order::item', 'web', '2024-09-04 11:12:16', '2024-09-04 11:12:16'),
(69, 'delete_order::item', 'web', '2024-09-04 11:12:16', '2024-09-04 11:12:16'),
(70, 'delete_any_order::item', 'web', '2024-09-04 11:12:16', '2024-09-04 11:12:16'),
(71, 'force_delete_order::item', 'web', '2024-09-04 11:12:16', '2024-09-04 11:12:16'),
(72, 'force_delete_any_order::item', 'web', '2024-09-04 11:12:16', '2024-09-04 11:12:16'),
(73, 'view_product', 'web', '2024-09-04 11:12:17', '2024-09-04 11:12:17'),
(74, 'view_any_product', 'web', '2024-09-04 11:12:17', '2024-09-04 11:12:17'),
(75, 'create_product', 'web', '2024-09-04 11:12:17', '2024-09-04 11:12:17'),
(76, 'update_product', 'web', '2024-09-04 11:12:17', '2024-09-04 11:12:17'),
(77, 'restore_product', 'web', '2024-09-04 11:12:17', '2024-09-04 11:12:17'),
(78, 'restore_any_product', 'web', '2024-09-04 11:12:18', '2024-09-04 11:12:18'),
(79, 'replicate_product', 'web', '2024-09-04 11:12:18', '2024-09-04 11:12:18'),
(80, 'reorder_product', 'web', '2024-09-04 11:12:18', '2024-09-04 11:12:18'),
(81, 'delete_product', 'web', '2024-09-04 11:12:18', '2024-09-04 11:12:18'),
(82, 'delete_any_product', 'web', '2024-09-04 11:12:19', '2024-09-04 11:12:19'),
(83, 'force_delete_product', 'web', '2024-09-04 11:12:19', '2024-09-04 11:12:19'),
(84, 'force_delete_any_product', 'web', '2024-09-04 11:12:19', '2024-09-04 11:12:19'),
(85, 'view_product::category', 'web', '2024-09-04 11:12:19', '2024-09-04 11:12:19'),
(86, 'view_any_product::category', 'web', '2024-09-04 11:12:19', '2024-09-04 11:12:19'),
(87, 'create_product::category', 'web', '2024-09-04 11:12:19', '2024-09-04 11:12:19'),
(88, 'update_product::category', 'web', '2024-09-04 11:12:20', '2024-09-04 11:12:20'),
(89, 'restore_product::category', 'web', '2024-09-04 11:12:20', '2024-09-04 11:12:20'),
(90, 'restore_any_product::category', 'web', '2024-09-04 11:12:20', '2024-09-04 11:12:20'),
(91, 'replicate_product::category', 'web', '2024-09-04 11:12:20', '2024-09-04 11:12:20'),
(92, 'reorder_product::category', 'web', '2024-09-04 11:12:20', '2024-09-04 11:12:20'),
(93, 'delete_product::category', 'web', '2024-09-04 11:12:20', '2024-09-04 11:12:20'),
(94, 'delete_any_product::category', 'web', '2024-09-04 11:12:21', '2024-09-04 11:12:21'),
(95, 'force_delete_product::category', 'web', '2024-09-04 11:12:21', '2024-09-04 11:12:21'),
(96, 'force_delete_any_product::category', 'web', '2024-09-04 11:12:21', '2024-09-04 11:12:21'),
(97, 'view_product::rating', 'web', '2024-09-04 11:12:21', '2024-09-04 11:12:21'),
(98, 'view_any_product::rating', 'web', '2024-09-04 11:12:21', '2024-09-04 11:12:21'),
(99, 'create_product::rating', 'web', '2024-09-04 11:12:22', '2024-09-04 11:12:22'),
(100, 'update_product::rating', 'web', '2024-09-04 11:12:22', '2024-09-04 11:12:22'),
(101, 'restore_product::rating', 'web', '2024-09-04 11:12:22', '2024-09-04 11:12:22'),
(102, 'restore_any_product::rating', 'web', '2024-09-04 11:12:22', '2024-09-04 11:12:22'),
(103, 'replicate_product::rating', 'web', '2024-09-04 11:12:22', '2024-09-04 11:12:22'),
(104, 'reorder_product::rating', 'web', '2024-09-04 11:12:22', '2024-09-04 11:12:22'),
(105, 'delete_product::rating', 'web', '2024-09-04 11:12:23', '2024-09-04 11:12:23'),
(106, 'delete_any_product::rating', 'web', '2024-09-04 11:12:23', '2024-09-04 11:12:23'),
(107, 'force_delete_product::rating', 'web', '2024-09-04 11:12:23', '2024-09-04 11:12:23'),
(108, 'force_delete_any_product::rating', 'web', '2024-09-04 11:12:23', '2024-09-04 11:12:23'),
(109, 'view_product::review', 'web', '2024-09-04 11:12:23', '2024-09-04 11:12:23'),
(110, 'view_any_product::review', 'web', '2024-09-04 11:12:23', '2024-09-04 11:12:23'),
(111, 'create_product::review', 'web', '2024-09-04 11:12:24', '2024-09-04 11:12:24'),
(112, 'update_product::review', 'web', '2024-09-04 11:12:24', '2024-09-04 11:12:24'),
(113, 'restore_product::review', 'web', '2024-09-04 11:12:24', '2024-09-04 11:12:24'),
(114, 'restore_any_product::review', 'web', '2024-09-04 11:12:24', '2024-09-04 11:12:24'),
(115, 'replicate_product::review', 'web', '2024-09-04 11:12:24', '2024-09-04 11:12:24'),
(116, 'reorder_product::review', 'web', '2024-09-04 11:12:24', '2024-09-04 11:12:24'),
(117, 'delete_product::review', 'web', '2024-09-04 11:12:25', '2024-09-04 11:12:25'),
(118, 'delete_any_product::review', 'web', '2024-09-04 11:12:25', '2024-09-04 11:12:25'),
(119, 'force_delete_product::review', 'web', '2024-09-04 11:12:25', '2024-09-04 11:12:25'),
(120, 'force_delete_any_product::review', 'web', '2024-09-04 11:12:25', '2024-09-04 11:12:25'),
(121, 'view_product::tag', 'web', '2024-09-04 11:12:25', '2024-09-04 11:12:25'),
(122, 'view_any_product::tag', 'web', '2024-09-04 11:12:25', '2024-09-04 11:12:25'),
(123, 'create_product::tag', 'web', '2024-09-04 11:12:26', '2024-09-04 11:12:26'),
(124, 'update_product::tag', 'web', '2024-09-04 11:12:26', '2024-09-04 11:12:26'),
(125, 'restore_product::tag', 'web', '2024-09-04 11:12:26', '2024-09-04 11:12:26'),
(126, 'restore_any_product::tag', 'web', '2024-09-04 11:12:26', '2024-09-04 11:12:26'),
(127, 'replicate_product::tag', 'web', '2024-09-04 11:12:26', '2024-09-04 11:12:26'),
(128, 'reorder_product::tag', 'web', '2024-09-04 11:12:26', '2024-09-04 11:12:26'),
(129, 'delete_product::tag', 'web', '2024-09-04 11:12:27', '2024-09-04 11:12:27'),
(130, 'delete_any_product::tag', 'web', '2024-09-04 11:12:27', '2024-09-04 11:12:27'),
(131, 'force_delete_product::tag', 'web', '2024-09-04 11:12:27', '2024-09-04 11:12:27'),
(132, 'force_delete_any_product::tag', 'web', '2024-09-04 11:12:27', '2024-09-04 11:12:27'),
(133, 'view_simple::product', 'web', '2024-09-04 11:12:27', '2024-09-04 11:12:27'),
(134, 'view_any_simple::product', 'web', '2024-09-04 11:12:27', '2024-09-04 11:12:27'),
(135, 'create_simple::product', 'web', '2024-09-04 11:12:28', '2024-09-04 11:12:28'),
(136, 'update_simple::product', 'web', '2024-09-04 11:12:28', '2024-09-04 11:12:28'),
(137, 'restore_simple::product', 'web', '2024-09-04 11:12:28', '2024-09-04 11:12:28'),
(138, 'restore_any_simple::product', 'web', '2024-09-04 11:12:28', '2024-09-04 11:12:28'),
(139, 'replicate_simple::product', 'web', '2024-09-04 11:12:29', '2024-09-04 11:12:29'),
(140, 'reorder_simple::product', 'web', '2024-09-04 11:12:29', '2024-09-04 11:12:29'),
(141, 'delete_simple::product', 'web', '2024-09-04 11:12:29', '2024-09-04 11:12:29'),
(142, 'delete_any_simple::product', 'web', '2024-09-04 11:12:30', '2024-09-04 11:12:30'),
(143, 'force_delete_simple::product', 'web', '2024-09-04 11:12:30', '2024-09-04 11:12:30'),
(144, 'force_delete_any_simple::product', 'web', '2024-09-04 11:12:30', '2024-09-04 11:12:30'),
(145, 'page_EditProfile', 'web', '2024-09-04 11:12:30', '2024-09-04 11:12:30'),
(146, 'page_PersonalAccessTokensPage', 'web', '2024-09-04 11:12:31', '2024-09-04 11:12:31'),
(147, 'page_UpdateProfileInformationPage', 'web', '2024-09-04 11:12:31', '2024-09-04 11:12:31'),
(148, 'view_coupon', 'web', '2024-09-04 11:20:23', '2024-09-04 11:20:23'),
(149, 'view_any_coupon', 'web', '2024-09-04 11:20:23', '2024-09-04 11:20:23'),
(150, 'create_coupon', 'web', '2024-09-04 11:20:23', '2024-09-04 11:20:23'),
(151, 'update_coupon', 'web', '2024-09-04 11:20:23', '2024-09-04 11:20:23'),
(152, 'restore_coupon', 'web', '2024-09-04 11:20:23', '2024-09-04 11:20:23'),
(153, 'restore_any_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(154, 'replicate_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(155, 'reorder_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(156, 'delete_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(157, 'delete_any_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(158, 'force_delete_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(159, 'force_delete_any_coupon', 'web', '2024-09-04 11:20:24', '2024-09-04 11:20:24'),
(160, 'view_store', 'web', '2024-09-04 11:20:25', '2024-09-04 11:20:25'),
(161, 'view_any_store', 'web', '2024-09-04 11:20:25', '2024-09-04 11:20:25'),
(162, 'create_store', 'web', '2024-09-04 11:20:25', '2024-09-04 11:20:25'),
(163, 'update_store', 'web', '2024-09-04 11:20:25', '2024-09-04 11:20:25'),
(164, 'restore_store', 'web', '2024-09-04 11:20:25', '2024-09-04 11:20:25'),
(165, 'restore_any_store', 'web', '2024-09-04 11:20:25', '2024-09-04 11:20:25'),
(166, 'replicate_store', 'web', '2024-09-04 11:20:26', '2024-09-04 11:20:26'),
(167, 'reorder_store', 'web', '2024-09-04 11:20:26', '2024-09-04 11:20:26'),
(168, 'delete_store', 'web', '2024-09-04 11:20:26', '2024-09-04 11:20:26'),
(169, 'delete_any_store', 'web', '2024-09-04 11:20:26', '2024-09-04 11:20:26'),
(170, 'force_delete_store', 'web', '2024-09-04 11:20:26', '2024-09-04 11:20:26'),
(171, 'force_delete_any_store', 'web', '2024-09-04 11:20:26', '2024-09-04 11:20:26');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `bv` decimal(8,2) DEFAULT NULL COMMENT 'Business Volume for the product',
  `description` text DEFAULT NULL,
  `inventory_count` int(11) NOT NULL DEFAULT 0,
  `low_stock_threshold` int(11) DEFAULT NULL,
  `short_description` text NOT NULL,
  `long_description` text NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `is_variable` tinyint(1) NOT NULL DEFAULT 0,
  `is_grouped` tinyint(1) NOT NULL DEFAULT 0,
  `is_simple` tinyint(1) NOT NULL DEFAULT 1,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `featured_image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `bv`, `description`, `inventory_count`, `low_stock_threshold`, `short_description`, `long_description`, `category_id`, `is_variable`, `is_grouped`, `is_simple`, `is_featured`, `featured_image`, `created_at`, `updated_at`, `team_id`) VALUES
(1, 'Toyota Camry', 24999.99, NULL, NULL, 0, NULL, 'Reliable and fuel-efficient family sedan.', 'Id quisquam deserunt non consectetur possimus eaque. Repellat quidem ut at omnis quia occaecati voluptate iure. Voluptas atque cupiditate culpa repellat nulla temporibus.', 1, 0, 0, 1, 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzFUW6twqcO8-l8tb4U8Oce04QPfqsKP0Waw&s', '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(2, 'Honda Accord', 26999.99, NULL, NULL, 0, NULL, 'Sleek design with excellent safety features.', 'Est ut sit error neque. Non voluptatem porro mollitia unde consequuntur id illum. Quidem iusto quia ut corrupti molestiae quam pariatur. Accusantium consequatur illum a sed ipsam ipsa nihil aperiam.', 1, 0, 0, 1, 0, 'https://vehicle-images.dealerinspire.com/179c-110011724/1HGCY2F69RA074488/cdf575ece6d269009028b405d8d967a6.png', '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(3, 'Nissan Altima', 23999.99, NULL, NULL, 0, NULL, 'Stylish sedan with advanced driver-assist features.', 'Minus id rerum illum asperiores excepturi ipsa. Qui corporis vel aliquid ut tenetur dolor. Blanditiis similique aspernatur eaque molestiae.', 1, 0, 0, 1, 0, 'https://media.ed.edmunds-media.com/nissan/altima/2025/oem/2025_nissan_altima_sedan_25-sv_fq_oem_1_1280.jpg', '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(4, 'Hyundai Sonata', 22999.99, NULL, NULL, 0, NULL, 'Comfortable midsize sedan with a tech-packed interior.', 'Rem sed qui ea autem amet eos. Delectus sint rem repellat enim qui ut.', 1, 0, 0, 1, 0, 'https://media.libozzle.com/media/65f24b3b-6d8d-4b73-b091-a8133f6a9fc4/JiMDVL1g.png', '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(5, 'Mazda 6', 24999.99, NULL, NULL, 0, NULL, 'Sporty sedan with excellent handling and efficiency.', 'Itaque ab rerum ex natus. Non unde earum neque quod. Aliquam aut vel quas libero. Voluptatem voluptatem dolore culpa autem.', 1, 0, 0, 1, 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS25DJwdR_DkXiGn1zTK1Dlr6W_kwTKEq7Yvw&s', '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(6, 'Ford Explorer', 39999.99, NULL, NULL, 0, NULL, 'Spacious and powerful SUV for off-road and family trips.', 'Unde ipsam incidunt modi iste dolores pariatur hic. Aperiam iste voluptatem aut beatae qui explicabo neque voluptatem.', 2, 0, 0, 1, 0, 'https://cdn.motor1.com/images/mgl/40N98Z/s3/2025-ford-explorer-st.jpg', '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(7, 'Jeep Wrangler', 34999.99, NULL, NULL, 0, NULL, 'Rugged off-road performance with an iconic design.', 'Perferendis animi et voluptatem reiciendis aut eos. Sit veritatis facere rerum hic ut nulla numquam. Vel eum placeat ut id aperiam id. Soluta iure perferendis amet minus sunt.', 2, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(8, 'Toyota RAV4', 30999.99, NULL, NULL, 0, NULL, 'Compact SUV with hybrid options and excellent fuel economy.', 'Fuga est voluptate nihil voluptate animi aspernatur sed. Voluptatem pariatur cumque exercitationem voluptatem non non. Unde aut exercitationem nemo debitis debitis.', 2, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(9, 'Honda CR-V', 32999.99, NULL, NULL, 0, NULL, 'Spacious and safe SUV with a smooth ride.', 'Velit ut iusto ut vel qui. Excepturi praesentium suscipit aperiam aperiam facere ad et. Ipsum deserunt non expedita voluptas perferendis odio et.', 2, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(10, 'Chevrolet Tahoe', 49999.99, NULL, NULL, 0, NULL, 'Large full-size SUV with plenty of space and towing power.', 'Eos facilis enim rerum rerum occaecati. Veritatis tenetur sint et esse quis. Aperiam commodi qui dolorem expedita fugiat eos iure. Et autem autem architecto quidem fugit voluptates ut.', 2, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(11, 'Ford F-150', 45999.99, NULL, NULL, 0, NULL, 'Best-selling full-size truck with superior towing capacity.', 'Voluptatem quia ut quasi animi rerum tenetur. Libero asperiores est doloremque ex. Necessitatibus aut aperiam ut aut.', 3, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(12, 'Chevrolet Silverado', 47999.99, NULL, NULL, 0, NULL, 'Heavy-duty truck with advanced features for towing.', 'Assumenda dolorem quia illum fugiat commodi ut. Illum accusantium eaque pariatur omnis. Fugiat aut repudiandae molestiae et nostrum sapiente. Aperiam quidem ut et deserunt iure non.', 3, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(13, 'Ram 1500', 42999.99, NULL, NULL, 0, NULL, 'Powerful and comfortable truck with excellent towing.', 'Animi vero incidunt amet pariatur quasi est quis. Eum iusto quis numquam labore et aut. Perspiciatis ullam est veniam necessitatibus.', 3, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(14, 'Toyota Tundra', 46999.99, NULL, NULL, 0, NULL, 'Rugged truck with a reliable V8 engine.', 'Nesciunt dicta ut maiores sint nobis pariatur. Ut alias rerum iure. Nesciunt fugit est laudantium officia ut nobis. Ea quia expedita harum voluptatem rerum.', 3, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(15, 'GMC Sierra', 48999.99, NULL, NULL, 0, NULL, 'Premium full-size truck with modern tech features.', 'Veritatis molestias distinctio temporibus iste dolor ullam. Porro est consequatur nesciunt et corrupti ad qui. Adipisci nulla voluptatem sit. Sed aspernatur sunt ex inventore distinctio excepturi impedit ea. Eos dolore ut voluptatem molestias dignissimos suscipit.', 3, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(16, 'Brake Pads Set', 99.99, NULL, NULL, 0, NULL, 'Ceramic brake pads for sedans and SUVs.', 'Necessitatibus beatae quidem dolorem eos ratione aut. Perspiciatis nulla corporis enim libero rerum quia nihil aut. Et pariatur eligendi dolor amet et dolore. Omnis doloribus qui eveniet facilis et.', 7, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(17, 'All-Season Tires', 499.99, NULL, NULL, 0, NULL, 'Durable tires suitable for all weather conditions.', 'Corrupti ipsa ipsa et sit. Dolorum voluptas vero a. Repudiandae est nihil ut explicabo quas facilis. Exercitationem provident eaque doloremque impedit eius eius.', 7, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(18, 'Car Battery', 149.99, NULL, NULL, 0, NULL, 'High-performance battery with a long lifespan.', 'Recusandae deserunt consequuntur earum necessitatibus eos. Velit enim qui tenetur est rerum necessitatibus architecto. Minima voluptatem incidunt animi aut. Natus possimus et suscipit sequi.', 7, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(19, 'LED Headlights', 59.99, NULL, NULL, 0, NULL, 'Bright, energy-efficient headlights for night driving.', 'Dignissimos ea et facilis. Rerum provident est minus quas qui ut. Neque quia voluptatibus et atque velit dolorum aliquid quia. Dolore expedita ducimus officia repellendus hic ut.', 7, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(20, 'Roof Rack', 199.99, NULL, NULL, 0, NULL, 'Universal roof rack for luggage and equipment.', 'Est nobis eum voluptate iste dolorum nesciunt. Dolor nihil ut ut commodi blanditiis error quia blanditiis. Molestias rerum ratione dolorem officiis voluptas natus nisi.', 7, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(21, 'Tesla Model 3', 39999.99, NULL, NULL, 0, NULL, 'Affordable electric car with great range and performance.', 'Similique voluptatem aliquam quis consequatur sed omnis similique. Necessitatibus eaque quo autem nihil voluptatem perferendis dolore. Voluptatem ut et ut voluptatem dignissimos asperiores. Sapiente hic fugiat in reiciendis hic a ad.', 4, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(22, 'Nissan Leaf', 29999.99, NULL, NULL, 0, NULL, 'Compact electric vehicle with impressive efficiency.', 'Necessitatibus saepe qui et ea sit. Est atque qui est porro unde quia optio. Laboriosam est enim sit ut quia saepe inventore.', 4, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(23, 'Chevrolet Bolt EV', 31999.99, NULL, NULL, 0, NULL, 'Affordable electric car with a long driving range.', 'Enim molestiae consequatur officiis nihil. Cum qui minima nesciunt nihil. Soluta provident impedit rerum ullam.', 4, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(24, 'Mercedes-Benz S-Class', 109999.99, NULL, NULL, 0, NULL, 'Ultimate luxury sedan with cutting-edge technology.', 'Alias est voluptas id delectus aut qui et. Quia quae expedita accusantium ut recusandae. Tempora deserunt doloremque eaque nostrum explicabo doloremque vel porro.', 6, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(25, 'BMW 7 Series', 99999.99, NULL, NULL, 0, NULL, 'Luxury sedan with a powerful engine and premium features.', 'Et necessitatibus a incidunt. Repudiandae et velit impedit. Molestiae eos eum debitis ipsum sunt.', 6, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(26, 'Audi A8', 96999.99, NULL, NULL, 0, NULL, 'Sleek design with a spacious and high-tech interior.', 'Vitae eveniet fugit ut ut ut. Omnis nemo numquam quas cumque consequatur. Sed aut perspiciatis commodi debitis accusamus. Beatae voluptatum velit ut officia. A tempore voluptatem facilis sit ipsa quidem.', 6, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(27, 'Lexus LS', 89999.99, NULL, NULL, 0, NULL, 'Luxury sedan combining comfort and performance.', 'Quae beatae quae iste quis. Non est incidunt impedit voluptates. Tempore nihil laboriosam magnam et ut. Fugit odit minus nulla voluptas possimus corporis.', 6, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(28, 'Harley-Davidson Sportster', 12999.99, NULL, NULL, 0, NULL, 'Iconic cruiser with great style and power.', 'Et veniam porro adipisci accusantium. Aliquid est inventore voluptatem rerum sed asperiores quidem iste. Nisi ipsum voluptatibus expedita. Ut voluptatibus cupiditate animi eveniet et.', 8, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(29, 'Yamaha YZF-R3', 5499.99, NULL, NULL, 0, NULL, 'Compact sportbike with excellent performance for beginners.', 'Magnam enim ex delectus at consectetur voluptatem. Sequi quasi natus eum porro ut mollitia. Omnis sed maxime impedit magnam laudantium distinctio.', 8, 0, 0, 1, 0, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(30, 'erwer', 33.00, NULL, '32erw', 33, 3, '32erw', '32erw', 1, 0, 0, 1, 0, NULL, '2025-02-07 21:26:00', '2025-02-07 21:26:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `parent_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `name`, `slug`, `parent_category_id`, `description`, `image`, `created_at`, `updated_at`, `team_id`) VALUES
(1, 'Sedans', 'sedans', NULL, 'Comfortable family cars.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(2, 'SUVs', 'suvs', NULL, 'Spacious off-road vehicles.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(3, 'Trucks', 'trucks', NULL, 'Heavy-duty trucks for work and travel.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(4, 'Electric Cars', 'electric', NULL, 'Eco-friendly electric vehicles.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(5, 'Hybrid Cars', 'hybrid', NULL, 'Hybrid vehicles with fuel and electric power.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(6, 'Luxury Cars', 'luxury', NULL, 'Premium cars with luxurious features.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(7, 'Car Parts & Accessories', 'car-parts-accessories', NULL, 'All types of car parts including wheels, brakes, engines, and more.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL),
(8, 'Motorcycles', 'motorcycles', NULL, 'Two-wheeled vehicles for various purposes.', NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_group`
--

CREATE TABLE `product_group` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) NOT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_rating`
--

CREATE TABLE `product_rating` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rating` int(11) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--

CREATE TABLE `product_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comments` text NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_tag`
--

CREATE TABLE `product_tag` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_variation`
--

CREATE TABLE `product_variation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `variation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ranks`
--

CREATE TABLE `ranks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `minimum_points` int(11) NOT NULL DEFAULT 0,
  `benefits` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ranks`
--

INSERT INTO `ranks` (`id`, `name`, `level`, `minimum_points`, `benefits`, `created_at`, `updated_at`) VALUES
(1, 'Bronze', 1, 0, '[\"Basic discounts\",\"Beginner offers\"]', NULL, NULL),
(2, 'Silver', 2, 500, '[\"10% discounts\",\"Limited free shipping\",\"Monthly coupons\"]', NULL, NULL),
(3, 'Gold', 3, 1500, '[\"15% discounts\",\"Unlimited free shipping\",\"Special deals\"]', NULL, NULL),
(4, 'Platinum', 4, 5000, '[\"20% discounts\",\"Exclusive products\",\"Periodic gifts\"]', NULL, NULL),
(5, 'Diamond', 5, 10000, '[\"25% discounts\",\"VIP support\",\"Early access to offers\"]', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `rating` int(11) NOT NULL,
  `review` text NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(2, 'system_admin', 'web', '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(3, 'customer', 'web', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(8, 2),
(9, 1),
(9, 2),
(10, 1),
(10, 2),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(18, 2),
(19, 1),
(19, 2),
(20, 1),
(20, 2),
(21, 1),
(21, 2),
(22, 1),
(22, 2),
(23, 1),
(23, 2),
(24, 1),
(24, 2),
(25, 1),
(25, 2),
(26, 1),
(26, 2),
(27, 1),
(27, 2),
(28, 1),
(28, 2),
(29, 1),
(29, 2),
(30, 1),
(30, 2),
(31, 1),
(31, 2),
(32, 1),
(32, 2),
(33, 1),
(33, 2),
(34, 1),
(34, 2),
(35, 1),
(35, 2),
(36, 1),
(36, 2),
(37, 1),
(37, 2),
(38, 1),
(38, 2),
(39, 1),
(39, 2),
(40, 1),
(40, 2),
(41, 1),
(41, 2),
(42, 1),
(42, 2),
(43, 1),
(43, 2),
(44, 1),
(44, 2),
(45, 1),
(45, 2),
(46, 1),
(46, 2),
(47, 1),
(47, 2),
(48, 1),
(48, 2),
(49, 1),
(49, 2),
(50, 1),
(50, 2),
(51, 1),
(51, 2),
(52, 1),
(52, 2),
(53, 1),
(53, 2),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(56, 1),
(56, 2),
(57, 1),
(57, 2),
(58, 1),
(58, 2),
(59, 1),
(59, 2),
(60, 1),
(60, 2),
(61, 1),
(61, 2),
(62, 1),
(62, 2),
(63, 1),
(63, 2),
(64, 1),
(64, 2),
(65, 1),
(65, 2),
(66, 1),
(66, 2),
(67, 1),
(67, 2),
(68, 1),
(68, 2),
(69, 1),
(69, 2),
(70, 1),
(70, 2),
(71, 1),
(71, 2),
(72, 1),
(72, 2),
(73, 1),
(73, 2),
(74, 1),
(74, 2),
(75, 1),
(75, 2),
(76, 1),
(76, 2),
(77, 1),
(77, 2),
(78, 1),
(78, 2),
(79, 1),
(79, 2),
(80, 1),
(80, 2),
(81, 1),
(81, 2),
(82, 1),
(82, 2),
(83, 1),
(83, 2),
(84, 1),
(84, 2),
(85, 1),
(85, 2),
(86, 1),
(86, 2),
(87, 1),
(87, 2),
(88, 1),
(88, 2),
(89, 1),
(89, 2),
(90, 1),
(90, 2),
(91, 1),
(91, 2),
(92, 1),
(92, 2),
(93, 1),
(93, 2),
(94, 1),
(94, 2),
(95, 1),
(95, 2),
(96, 1),
(96, 2),
(97, 1),
(97, 2),
(98, 1),
(98, 2),
(99, 1),
(99, 2),
(100, 1),
(100, 2),
(101, 1),
(101, 2),
(102, 1),
(102, 2),
(103, 1),
(103, 2),
(104, 1),
(104, 2),
(105, 1),
(105, 2),
(106, 1),
(106, 2),
(107, 1),
(107, 2),
(108, 1),
(108, 2),
(109, 1),
(109, 2),
(110, 1),
(110, 2),
(111, 1),
(111, 2),
(112, 1),
(112, 2),
(113, 1),
(113, 2),
(114, 1),
(114, 2),
(115, 1),
(115, 2),
(116, 1),
(116, 2),
(117, 1),
(117, 2),
(118, 1),
(118, 2),
(119, 1),
(119, 2),
(120, 1),
(120, 2),
(121, 1),
(121, 2),
(122, 1),
(122, 2),
(123, 1),
(123, 2),
(124, 1),
(124, 2),
(125, 1),
(125, 2),
(126, 1),
(126, 2),
(127, 1),
(127, 2),
(128, 1),
(128, 2),
(129, 1),
(129, 2),
(130, 1),
(130, 2),
(131, 1),
(131, 2),
(132, 1),
(132, 2),
(133, 1),
(133, 2),
(134, 1),
(134, 2),
(135, 1),
(135, 2),
(136, 1),
(136, 2),
(137, 1),
(137, 2),
(138, 1),
(138, 2),
(139, 1),
(139, 2),
(140, 1),
(140, 2),
(141, 1),
(141, 2),
(142, 1),
(142, 2),
(143, 1),
(143, 2),
(144, 1),
(144, 2),
(145, 1),
(145, 2),
(146, 1),
(146, 2),
(147, 1),
(147, 2),
(148, 1),
(148, 2),
(149, 1),
(149, 2),
(150, 1),
(150, 2),
(151, 1),
(151, 2),
(152, 1),
(152, 2),
(153, 1),
(153, 2),
(154, 1),
(154, 2),
(155, 1),
(155, 2),
(156, 1),
(156, 2),
(157, 1),
(157, 2),
(158, 1),
(158, 2),
(159, 1),
(159, 2),
(160, 1),
(160, 2),
(161, 1),
(161, 2),
(162, 1),
(162, 2),
(163, 1),
(163, 2),
(164, 1),
(164, 2),
(165, 1),
(165, 2),
(166, 1),
(166, 2),
(167, 1),
(167, 2),
(168, 1),
(168, 2),
(169, 1),
(169, 2),
(170, 1),
(170, 2),
(171, 1),
(171, 2);

-- --------------------------------------------------------

--
-- Table structure for table `rsp_history`
--

CREATE TABLE `rsp_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `rsp_value` decimal(10,2) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rsp_history`
--

INSERT INTO `rsp_history` (`id`, `user_id`, `rsp_value`, `description`, `created_at`, `updated_at`) VALUES
(1, 2, 2.00, '', '2025-02-07 22:43:31', '2025-02-07 22:43:31'),
(2, 2, 3.00, '', '2025-02-07 22:43:37', '2025-02-07 22:43:37'),
(3, 3, 5.00, '', '2025-02-07 23:04:55', '2025-02-07 23:04:55'),
(4, 10, 33.00, '', '2025-02-07 23:56:43', '2025-02-07 23:56:43');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `simple_product`
--

CREATE TABLE `simple_product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `value` text NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `value`, `description`, `created_at`, `updated_at`) VALUES
(1, 'name', 'Liberu Ecommerce', NULL, '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(2, 'currency', '£', NULL, '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(3, 'default_language', 'en', NULL, '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(4, 'address', '123 Real Estate St, London, UK', NULL, '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(5, 'country', 'United Kingdom', NULL, '2025-02-01 19:00:54', '2025-02-01 19:00:54'),
(6, 'email', 'info@liberurealestate.com', NULL, '2025-02-01 19:00:54', '2025-02-01 19:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `personal_team` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `user_id`, `name`, `personal_team`, `created_at`, `updated_at`) VALUES
(1, 1, 'default', 0, '2025-02-01 19:00:54', '2025-02-01 19:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `team_invitations`
--

CREATE TABLE `team_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) NOT NULL,
  `role` varchar(191) DEFAULT NULL,
  `token` varchar(64) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_user`
--

CREATE TABLE `team_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_user`
--

INSERT INTO `team_user` (`id`, `team_id`, `user_id`, `role`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55'),
(2, 1, 2, NULL, '2025-02-01 19:00:55', '2025-02-01 19:00:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phonenumber` varchar(191) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` enum('customer','admin') DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `country_id` bigint(20) UNSIGNED DEFAULT NULL,
  `city_id` bigint(20) UNSIGNED DEFAULT NULL,
  `rank_id` bigint(20) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phonenumber`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`, `user_type`, `parent_id`, `country_id`, `city_id`, `rank_id`, `active`, `address`) VALUES
(1, 'Admin User', 'admin@admin.com', '773030069', '2025-02-01 19:00:54', '$2y$12$6cv6tP82pbGUIYTNUguaXOUK3QAIIK5W9AFjA3xMwLXV0nw/e.2o.', NULL, NULL, NULL, NULL, 1, NULL, '2025-02-01 19:00:54', '2025-02-07 22:10:18', 'admin', NULL, NULL, NULL, NULL, 1, NULL),
(2, 'Staff User', 'staff@example.com', '734320905', '2025-02-01 19:00:55', '$2y$12$z0Lmd/78n1NcCZyEhyvay.nv8idM0.39ZfZNChvVHyqqhVvLYKaA2', NULL, NULL, NULL, NULL, 1, NULL, '2025-02-01 19:00:55', '2025-02-07 22:14:08', 'admin', NULL, NULL, NULL, NULL, 1, NULL),
(3, 'cssd', 'admin@admin.comd', '3323423422', NULL, '$2y$12$a..jM4mT4jBypzWU7shmZebgMhb9LKfeH38ZsMXmGu3J6pRruYX8a', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:03:16', '2025-02-07 23:03:16', 'customer', NULL, NULL, NULL, NULL, 1, NULL),
(4, 'werwer wer', 'admin123@admin.comw', '123123123', NULL, '$2y$12$eD18QPzhl6VXU7sERDVFluOOUpGD47jSjLH8pFeGomQ8xGSlzb6Uy', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:05:25', '2025-02-07 23:05:25', 'customer', NULL, NULL, NULL, NULL, 1, NULL),
(6, 'abdo d', 'ad3min@admin.com', '33212312323', NULL, '$2y$12$280Wh2UVASsjcqtL1unfHeDo/tRhNy7ArPmNxUvyRSuEAaCXavjgu', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:11:02', '2025-02-07 23:11:02', 'customer', NULL, NULL, NULL, NULL, 1, NULL),
(7, 'kdkdk', '33admin@admin.com', '34234234234', NULL, '$2y$12$nhMrQ7Dia3tNieN1S3R/c.BbBuFt7GzWsp6QAJfjPg4esck0UygXi', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:11:30', '2025-02-07 23:11:30', 'customer', NULL, NULL, NULL, NULL, 1, NULL),
(8, 'jjjjjwjwj', 'jw@E.DD', '123123412', NULL, '$2y$12$YbQc4zJqla5pXRwCC86YF.Jd8cBrAigHMTxIV9aPSyBzCHUyHPo6W', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:11:46', '2025-02-07 23:11:46', 'customer', NULL, NULL, NULL, NULL, 1, NULL),
(9, 'sdf', 'e93dk@dd.cc', '3939393939', NULL, '$2y$12$0dfCeYerP1d/6wehvWdEJ.8oc1s0BByx4FZ6JKrn/zY8qywvzZNce', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:19:05', '2025-02-07 23:19:05', 'customer', 8, NULL, NULL, NULL, 1, NULL),
(10, '33399e9', '39393@EKEK.DDD', '393939393939', NULL, '$2y$12$TNmzIr9U193D6ITMEzik/O6rSOGUR21TJeom37KnASCuX3uBKkMIe', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-07 23:19:30', '2025-02-07 23:55:29', 'customer', 8, 1, 2, 1, 1, NULL),
(11, '3ee ee ee', 'ee@dd.com33', '12345678912', NULL, '$2y$12$2dKfx3U8YtB9A10FYhhMBOQsFdjKlroQ0qBGqUxOnfgGCmDiExv/G', NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-10 00:47:22', '2025-02-10 00:47:22', 'customer', 9, 1, 1, NULL, 0, '234');

-- --------------------------------------------------------

--
-- Table structure for table `user_plans`
--

CREATE TABLE `user_plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `plan` text NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `variations`
--

CREATE TABLE `variations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `value` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `share_token` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bv_history`
--
ALTER TABLE `bv_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bv_history_user_id_foreign` (`user_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_items_user_id_foreign` (`user_id`),
  ADD KEY `cart_items_product_id_foreign` (`product_id`),
  ADD KEY `cart_items_team_id_foreign` (`team_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cities_country_id_foreign` (`country_id`);

--
-- Indexes for table `collections`
--
ALTER TABLE `collections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `collections_team_id_foreign` (`team_id`);

--
-- Indexes for table `collection_items`
--
ALTER TABLE `collection_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `collection_items_collection_id_foreign` (`collection_id`),
  ADD KEY `collection_items_product_id_foreign` (`product_id`);

--
-- Indexes for table `connected_accounts`
--
ALTER TABLE `connected_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `connected_accounts_user_id_id_index` (`user_id`,`id`),
  ADD KEY `connected_accounts_provider_provider_id_index` (`provider`,`provider_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `countries_name_unique` (`name`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`),
  ADD KEY `coupons_team_id_foreign` (`team_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customers_team_id_foreign` (`team_id`);

--
-- Indexes for table `downloadable_products`
--
ALTER TABLE `downloadable_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `downloadable_products_product_id_foreign` (`product_id`),
  ADD KEY `downloadable_products_team_id_foreign` (`team_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `groups_team_id_foreign` (`team_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_team_id_foreign` (`team_id`);

--
-- Indexes for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_logs_product_id_foreign` (`product_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoices_customer_id_foreign` (`customer_id`),
  ADD KEY `invoices_order_id_foreign` (`order_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_uuid_unique` (`uuid`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `media_order_column_index` (`order_column`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menus_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_customer_id_foreign` (`customer_id`),
  ADD KEY `orders_team_id_foreign` (`team_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_orderable_type_orderable_id_index` (`orderable_type`,`orderable_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`),
  ADD KEY `pages_parent_page_id_foreign` (`parent_page_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_methods_user_id_foreign` (`user_id`),
  ADD KEY `payment_methods_team_id_foreign` (`team_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_team_id_foreign` (`team_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_categories_slug_unique` (`slug`),
  ADD KEY `product_categories_parent_category_id_foreign` (`parent_category_id`),
  ADD KEY `product_categories_team_id_foreign` (`team_id`);

--
-- Indexes for table `product_group`
--
ALTER TABLE `product_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_group_product_id_foreign` (`product_id`),
  ADD KEY `product_group_group_id_foreign` (`group_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_images_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_rating`
--
ALTER TABLE `product_rating`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_rating_product_id_foreign` (`product_id`),
  ADD KEY `product_rating_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_reviews_product_id_foreign` (`product_id`),
  ADD KEY `product_reviews_customer_id_foreign` (`customer_id`),
  ADD KEY `product_reviews_team_id_foreign` (`team_id`);

--
-- Indexes for table `product_tag`
--
ALTER TABLE `product_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_tag_product_id_foreign` (`product_id`),
  ADD KEY `product_tag_tag_id_foreign` (`tag_id`);

--
-- Indexes for table `product_variation`
--
ALTER TABLE `product_variation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_variation_product_id_foreign` (`product_id`);

--
-- Indexes for table `ranks`
--
ALTER TABLE `ranks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ranks_name_unique` (`name`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ratings_user_id_foreign` (`user_id`),
  ADD KEY `ratings_product_id_foreign` (`product_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reviews_user_id_foreign` (`user_id`),
  ADD KEY `reviews_product_id_foreign` (`product_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `rsp_history`
--
ALTER TABLE `rsp_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rsp_history_user_id_foreign` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `simple_product`
--
ALTER TABLE `simple_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `simple_product_product_id_foreign` (`product_id`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `site_settings_name_unique` (`name`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_user_id_index` (`user_id`);

--
-- Indexes for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_invitations_team_id_email_unique` (`team_id`,`email`),
  ADD UNIQUE KEY `team_invitations_token_unique` (`token`);

--
-- Indexes for table `team_user`
--
ALTER TABLE `team_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_user_team_id_user_id_unique` (`team_id`,`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phonenumber_unique` (`phonenumber`),
  ADD KEY `users_parent_id_index` (`parent_id`),
  ADD KEY `users_country_id_foreign` (`country_id`),
  ADD KEY `users_city_id_foreign` (`city_id`),
  ADD KEY `users_rank_id_foreign` (`rank_id`);

--
-- Indexes for table `user_plans`
--
ALTER TABLE `user_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_plans_user_id_foreign` (`user_id`);

--
-- Indexes for table `variations`
--
ALTER TABLE `variations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wishlists_user_id_product_id_unique` (`user_id`,`product_id`),
  ADD UNIQUE KEY `wishlists_share_token_unique` (`share_token`),
  ADD KEY `wishlists_product_id_foreign` (`product_id`),
  ADD KEY `wishlists_team_id_foreign` (`team_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bv_history`
--
ALTER TABLE `bv_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `collections`
--
ALTER TABLE `collections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `collection_items`
--
ALTER TABLE `collection_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `connected_accounts`
--
ALTER TABLE `connected_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `downloadable_products`
--
ALTER TABLE `downloadable_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_group`
--
ALTER TABLE `product_group`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_rating`
--
ALTER TABLE `product_rating`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_reviews`
--
ALTER TABLE `product_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_tag`
--
ALTER TABLE `product_tag`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_variation`
--
ALTER TABLE `product_variation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ranks`
--
ALTER TABLE `ranks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rsp_history`
--
ALTER TABLE `rsp_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `simple_product`
--
ALTER TABLE `simple_product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `team_invitations`
--
ALTER TABLE `team_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team_user`
--
ALTER TABLE `team_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_plans`
--
ALTER TABLE `user_plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variations`
--
ALTER TABLE `variations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bv_history`
--
ALTER TABLE `bv_history`
  ADD CONSTRAINT `bv_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cart_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_items_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `collections`
--
ALTER TABLE `collections`
  ADD CONSTRAINT `collections_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `collection_items`
--
ALTER TABLE `collection_items`
  ADD CONSTRAINT `collection_items_collection_id_foreign` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `collection_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `coupons`
--
ALTER TABLE `coupons`
  ADD CONSTRAINT `coupons_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `downloadable_products`
--
ALTER TABLE `downloadable_products`
  ADD CONSTRAINT `downloadable_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `downloadable_products_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  ADD CONSTRAINT `inventory_logs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoices_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `menus_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `pages_parent_page_id_foreign` FOREIGN KEY (`parent_page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_methods_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `product_categories_parent_category_id_foreign` FOREIGN KEY (`parent_category_id`) REFERENCES `product_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_categories_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_group`
--
ALTER TABLE `product_group`
  ADD CONSTRAINT `product_group_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  ADD CONSTRAINT `product_group_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_rating`
--
ALTER TABLE `product_rating`
  ADD CONSTRAINT `product_rating_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `product_rating_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD CONSTRAINT `product_reviews_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `product_reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `product_reviews_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_tag`
--
ALTER TABLE `product_tag`
  ADD CONSTRAINT `product_tag_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `product_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);

--
-- Constraints for table `product_variation`
--
ALTER TABLE `product_variation`
  ADD CONSTRAINT `product_variation_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rsp_history`
--
ALTER TABLE `rsp_history`
  ADD CONSTRAINT `rsp_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `simple_product`
--
ALTER TABLE `simple_product`
  ADD CONSTRAINT `simple_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD CONSTRAINT `team_invitations_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_rank_id_foreign` FOREIGN KEY (`rank_id`) REFERENCES `ranks` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_plans`
--
ALTER TABLE `user_plans`
  ADD CONSTRAINT `user_plans_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
